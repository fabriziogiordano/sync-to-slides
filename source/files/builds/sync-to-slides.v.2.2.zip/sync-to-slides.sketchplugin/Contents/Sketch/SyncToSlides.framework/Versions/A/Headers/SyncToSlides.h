//
//  SyncToSlides.h
//  SyncToSlides
//
//  Created by Siddhartha Gudipati on 3/17/17.
//  Copyright © 2017 gsid. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SyncToSlides.
FOUNDATION_EXPORT double SyncToSlidesVersionNumber;

//! Project version string for SyncToSlides.
FOUNDATION_EXPORT const unsigned char SyncToSlidesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SyncToSlides/PublicHeader.h>

#import "ServiceManager.h"

